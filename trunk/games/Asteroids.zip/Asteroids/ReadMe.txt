Asteroids Sample Game

Shows off SlimDX and the Sample Framework.
Not yet finished, but the basic stuff is all there.
Controls are:
  Escape     - Quit
  F1         - Toggle Fullscreen
  Enter      - Create new asteroid
  Space      - Shoot
  W,A,S,D    - Move
  Arrow Keys - Move